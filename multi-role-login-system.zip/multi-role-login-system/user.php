<?php
session_start();
include('./conn/conn.php');

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Fetch the user's name from the database
    $stmt = $conn->prepare("SELECT `name` FROM `tbl_user` WHERE `tbl_user_id` = :user_id");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        $row = $stmt->fetch();
        $user_name = $row['name'];
    }

    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>User Dashboard</title>

        <!-- Google Fonts - Import Aptos -->
        <link href="https://fonts.googleapis.com/css2?family=Aptos:wght@400;500;600&display=swap" rel="stylesheet">

        <!-- Bootstrap 4 CSS -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

        <style>
            * {
                color: black;
                box-sizing: border-box;
                font-family: 'Aptos', sans-serif;
            }

            body {
                margin: 0;
                font-family: 'Aptos', sans-serif;
                background-image: url('path-to-your-background-image.jpg');
                width: 100%;
                height: 100%;        
                background-repeat: no-repeat;
                background-size: cover;
                overflow-y: auto; /* Allow the page to scroll */
            }

            .header {
                overflow: hidden;
                background: transparent;
                padding: 20px 18px;
                margin: 0 7%;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            .header .header-right {
                display: flex;
                align-items: center;
            }

            .header a {
                padding-right: 30px;
                text-decoration: none;
                font-size: 18px;
                line-height: 25px;
                white-space: nowrap; /* Ensures no text wrapping */
            }

            .header .logo {
                font-size: 20px;
                font-weight: bold;
            }

            .header a#homeLink {
                padding-right: 50px; /* Make the Home link larger if needed */
                font-size: 20px;
                font-weight: bold;
                flex-grow: 1;  /* Expands the 'Home' link to take more space */
            }

            .kodfun-galeri {
                display: flex;
                height: 20rem;
                gap: 1rem;
                overflow-x: auto; /* Allow horizontal scrolling for gallery */
            }

            .kodfun-galeri > div {
                flex: 1;
                border-radius: 1rem;
                background-position: center;
                background-repeat: no-repeat;
                background-size: auto 200%;
                transition: all .8s cubic-bezier(.25, .4, .45, 1.4);
            }

            .kodfun-galeri > div:hover {
                flex: 5;
            }

            .center-button-container {
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                gap: 20px;
                margin-top: 30px; /* Add space between gallery and buttons */
                width: 100%; /* Ensure it takes full width for smaller screens */
                padding: 0 10px;
            }

            .center-button {
                padding: 20px 40px;
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 8px;
                font-size: 20px;
                cursor: pointer;
                width: 300px; 
                height: 80px; 
                display: flex;
                justify-content: center;
                align-items: center;
                gap: 15px;
                text-align: center;
            }

            .center-button:hover {
                background-color: #45a049;
                transform: scale(1.05);
            }

            .center-button i {
                font-size: 30px;
            }

            /* Modal Styling */
            .modal {
                display: none;
                position: fixed;
                z-index: 1;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.5); /* Background color with transparency */
            }

            .modal-content {
                background-color: #fff;
                padding: 1rem 2rem;
                border-radius: 10px;
                margin: 10% auto;
                width: 90%; /* Adjusting width to make it responsive */
                max-width: 800px; /* Maximum width */
            }

            .close {
                color: #aaa;
                float: right;
                font-size: 28px;
                font-weight: bold;
                cursor: pointer;
            }

            .close:hover,
            .close:focus {
                color: black;
                text-decoration: none;
            }

            /* Media Queries for Responsiveness */
            @media (max-width: 768px) {
                .header a {
                    font-size: 16px; /* Smaller font on smaller screens */
                    padding-right: 20px; /* Adjust padding for small screens */
                }

                .center-button-container {
                    top: 50%;
                }
            }

            /* Know More Section */
            .know-more-section {
                background-color: #4CAF50;  /* Green background */
                color: white;               /* White text color for contrast */
                padding: 30px 0;
                margin-top: 50px;
            }

            .know-more-section h3 {
                font-size: 22px;
                font-weight: bold;
                margin-bottom: 20px;
                color: white; /* White color for headings */
            }

            .know-more-section ul {
                list-style-type: none;
                padding: 0;
            }

            .know-more-section ul li {
                margin-bottom: 10px;
            }

            .know-more-section ul li a {
                text-decoration: none;
                color: #fff;  /* White links */
                font-size: 16px;
            }

            .know-more-section ul li a:hover {
                color: #e6f7e6; /* Light green on hover */
            }

            .know-more-section p {
                font-size: 16px;
                margin-bottom: 10px;
                color: white; /* White color for paragraph text */
            }

            .know-more-section .container {
                max-width: 1200px;
                margin: 0 auto;
            }

            .know-more-section .row {
                display: flex;
                flex-wrap: wrap;
            }

            .know-more-section .col-md-6 {
                width: 50%;
                padding: 10px;
            }

            @media (max-width: 768px) {
                .know-more-section .col-md-6 {
                    width: 100%;
                }
            }

        </style>
    </head>

    <body>

        <!-- Header with the section links -->
        <div class="header">
            <a class="logo" href="#">Assistance to Individuals In Crisis Situations</a>
            <div class="header-right">
                <a href="#" id="homeLink">Home</a>
                <a href="#" id="aboutUsLink">About Us</a>
                <a href="#" id="newsLink">News & Events</a>
                <a href="#" id="servicesLink">Services</a>
                <a href="#" id="contactUsLink">Contact Us</a>
                <input type="text" placeholder="Search..">
            </div>
        </div>

        <!-- Image Gallery -->
        <div class="kodfun-galeri">
            <div style="background-image: url('Img/2.png');"></div>
            <div style="background-image: url('Img/image-277.png');"></div>
            <div style="background-image: url('Img/DSWD-CASH-AID_banner-1896x800.jpg');"></div>
            <div style="background-image: url('Img/Cash-aid-distribution-PHILSTAR-EDDGUMBAN.jpg');"></div>
            <div style="background-image: url('Img/6-venues-open-1024x768.jpg');"></div>
        </div>

        <!-- Centered Buttons Below Gallery -->
        <div class="center-button-container">
            <button class="center-button" onclick="window.location.href='medical_assistance_requirements.php'">Medical Assistance</button>
            <button class="center-button" onclick="window.location.href='burial_assistance_requirements.php'">Burial Assistance</button>
            <button class="center-button" onclick="window.location.href='strange_behavior_assistance_requirements.php'">Strange Behavior Assistance</button>
        </div>

        <!-- Know More Section -->
        <div class="know-more-section">
            <div class="container">
                <div class="row">
                    <!-- Quick Links Column -->
                    <div class="col-md-6">
                        <h3>Quick Links</h3>
                        <ul>
                            <li><a href="#">Medical Assistance</a></li>
                            <li><a href="#">Burial Assistance</a></li>
                            <li><a href="#">Strange Behavior Assistance</a></li>
                            <li><a href="#">News & Events</a></li>
                        </ul>
                    </div>

                    <!-- Contact Us Column -->
                    <div class="col-md-6">
                        <h3>Contact Us</h3>
                        <p>If you have any questions or need assistance, feel free to reach out to us:</p>
                        <p>Email: ciu@dswd.gov.ph</p>
                        <p>Phone: 09474822864 (Smart) 09162471194 (Globe)</p>
                        <p>Address: Municipal Hall, Rizal St., Zone lll, Murcia Negros Occidental</p>
                    </div>
                </div>
            </div>
        </div>

        

    </body>
    </html>

<?php
} else {
    header("Location: http://localhost/multi-role-login-system/");
}
?>
