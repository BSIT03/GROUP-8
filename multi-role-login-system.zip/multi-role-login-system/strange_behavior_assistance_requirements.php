<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Medical Assistance Center</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>

  <div class="container">
    <header>
      <h1>Strange Behavior Assistance</h1>
      <p>Strange Behavior requirements below</p>
    </header>

    <section class="form-section">
      <div class="box">
        <h2>Requirements</h2>
        <li>Isa (1) ka Origanl nga Barangay Indigency kag 1 xerox copy</li>
        <br>
        <li>Isa (1) ka Origanl nga Medical Certificate kag 1  xerox copy</li>
        <br>
        <li>Isa (1) ka OriganlResibo nga ginbayadan</li>
        <br>
        <li>(2) ka Photo Copy sang Valid ID sang gaprocess nga may address nga Murcia </li>
       </div>
    </section>

   
    <section class="form-section">
      <div class="box">
        <h3>Note</h3>
        <br>
        <p>Authorization halin sa asawa/bana o sa bata sang napatay kung lain nga pamilya ang maprocess.<p>
  </div>

    <section class="form-section">
      <div class="box">
        <h4>PAALALA</h4>
        <br>
        <p>Ang lahat ng pinansyal na tulong mula sa Crisis Intervention Division ng DSWD ay buong matatanggap ng mga benepisaryo.<p>
        <br>
        <p>Walang sino mang empleyado o hindi empleyado ng ahensya ang awtorisado na magkaltas o magpataw ng ano mang pinansyal na singil mula rito.<p>
        <br>
        <p>Ang DSWD ay hindi tumatanggap ng mga fake/peke na mga dokumento at ito ay mapatunayan ng DSWD may kulang itong parusa at dadaan ito sa tamang proseso upang bigyan ng tamang aksyon.<p>
        <br>
        <p><a href="./endpoint/apply.php" target="_blank" style="color: #4CAF50; text-decoration: none; font-weight: bold;">Apply</a></p>
  </div>

</body>
</html>
         <style>
            /* styles.css */

            /* Reset some basic styles */
            * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            }

            body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            padding: 20px;
            }

            .container {
            max-width: 900px;
            margin: 0 auto;
            }

            header {
            text-align: center;
            padding: 20px;
            background-color: #4CAF50;
            color: white;
            border-radius: 8px;
            }

            header h1 {
            font-size: 2.5em;
            }

            header p {
            font-size: 1.2em;
            }

            .form-section {
            margin-top: 30px;
            }

            .box {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            }

            h2 {
            color: #333;
            font-size: 1.8em;
            margin-bottom: 20px;
            }

            form {
            display: flex;
            flex-direction: column;
            }

            label {
            font-size: 1.1em;
            margin-bottom: 5px;
            color: #333;
            }

            input, textarea {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            }

            textarea {
            resize: vertical;
            }

            button {
            padding: 12px 20px;
            background-color: #4CAF50;
            color: white;
            font-size: 1.2em;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            }

            button:hover {
            background-color: #45a049;
            }

            button:active {
            background-color: #388e3c;
            }
            </style>
      </head>
    <body>