<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "multi_role_login_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$success = false; // Initialize success flag

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect form data
    $first_name = $_POST['first-name'];
    $middle_name = $_POST['middle-name'];
    $last_name = $_POST['last-name'];
    $age = $_POST['age'];
    $birthday = $_POST['birthday'];
    $reason = $_POST['reason'];
    $address = $_POST['address'];
    $gender = $_POST['sex'];
    $status = $_POST['status'];
    $email = $_POST['email']; // Collect email input

    // Prepare SQL statement
    $sql = "INSERT INTO application (first_name, middle_name, last_name, age, birthday, reason, address, gender, status, email)
            VALUES ('$first_name', '$middle_name', '$last_name', '$age', '$birthday', '$reason', '$address', '$gender', '$status', '$email')";

    // Execute SQL query
    if ($conn->query($sql) === TRUE) {
        $success = true; // Set success flag for notification
    } else {
        $success = false; // Set failure flag
    }

    // Close connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fill Form Application</title>
    <style>
        /* Basic styling for the form */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
        }

        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        label {
            font-size: 14px;
            color: #333;
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="number"],
        input[type="email"],
        input[type="tel"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }

        textarea {
            resize: vertical;
        }

        .radio-group {
            display: flex;
            justify-content: space-around;
            margin-bottom: 15px;
        }

        .radio-group label {
            font-size: 14px;
        }

        .submit-btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }

        .submit-btn:hover {
            background-color: #45a049;
        }

        /* Success notification styling */
        .success-notification {
            position: fixed;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            background-color: #4CAF50;
            color: white;
            padding: 15px;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            z-index: 1000;
            display: none;
            opacity: 0;
            transition: opacity 0.5s ease-in-out;
        }

        .success-notification.show {
            display: block;
            opacity: 1;
        }
    </style>
</head>
<body>

    <!-- Success notification -->
    <?php if (isset($success) && $success): ?>
        <div id="success-notification" class="success-notification">
            Application Submitted Successfully! Your information has been received and is being processed.
        </div>
    <?php endif; ?>

    <div class="form-container">
        <h2>Fill Up the Form</h2>
        <form action="apply.php" method="post">
            <label for="first-name">First Name:</label>
            <input type="text" id="first-name" name="first-name" required>

            <label for="middle-name">Middle Name:</label>
            <input type="text" id="middle-name" name="middle-name" required>

            <label for="last-name">Last Name:</label>
            <input type="text" id="last-name" name="last-name" required>

            <label for="age">Age:</label>
            <input type="number" id="age" name="age" required>

            <label for="birthday">Select your Birthday:</label>
            <input type="date" id="birthday" name="birthday" required>

            <label for="reason">Reason for Assistance:</label>
            <select id="reason" name="reason" required>
                <option value="">Select a Assistance</option>
                <option value="medical_assistance">Medical Assistance</option>
                <option value="burial_assistance">Burial Assistance</option>
                <option value="strange_behavior_assistance">Strange Behavior Assistance</option>
            </select><br><br>

            <label for="address">Address:</label>
            <textarea id="address" name="address" rows="4" required></textarea>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="sex">Sex:</label>
            <div class="radio-group">
                <label>
                    <input type="radio" name="sex" value="male" required> Male
                </label>
                <label>
                    <input type="radio" name="sex" value="female" required> Female
                </label>
                <label>
                    <input type="radio" name="sex" value="other" required> Other
                </label>
            </div>

            <label for="status">Status:</label>
            <div class="radio-group">
                <label>
                    <input type="radio" name="status" value="Single" required> Single
                </label>
                <label>
                    <input type="radio" name="status" value="Married" required> Married
                </label>
                <label>
                    <input type="radio" name="status" value="Widow/er" required> Widow/er
                </label>
                <label>
                    <input type="radio" name="status" value="Other" required> Other
                </label>
            </div>

            <button type="submit" class="submit-btn">Submit</button>
        </form>
    </div>

    <script>
        // Show success notification if set by PHP
        <?php if (isset($success) && $success): ?>
            setTimeout(function() {
                var notification = document.getElementById('success-notification');
                notification.classList.add('show');
                
                // Hide the notification after 5 seconds
                setTimeout(function() {
                    notification.classList.remove('show');
                }, 5000);
            }, 100);
        <?php endif; ?>
    </script>

</body>
</html>
